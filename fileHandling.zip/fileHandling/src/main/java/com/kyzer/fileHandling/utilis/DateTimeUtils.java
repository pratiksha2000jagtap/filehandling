package com.kyzer.fileHandling.utilis;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DateTimeUtils {

	public static String getCurrentDateFormatted() {
		// Gets Current date
        LocalDate currentDate = LocalDate.now();
        // use for formating date in yyyy/dd/MM 
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/dd/MM");
        // returns currentDate using specified format
        return currentDate.format(formatter);
    }
	
	public static String getCurrentDateFormatted1() {
		// Gets Current date
        LocalDate currentDate = LocalDate.now();
        // use foe formating date in dd/MM/yyyy
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        // returns currentDate using specified format
        return currentDate.format(formatter);
    }
	
	public static String CurrentDateTimeFormaterr() {
		LocalTime currentTime = LocalTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		return currentTime.format(formatter);
		
		
	}
	// local date time format 
	public static DateTimeFormatter DateTimeFormat= DateTimeFormatter.ofPattern("yyyy-dd-MM HH:mm:ss");
	
	
	public static String getCurrentDateTimeFormatted() {
        LocalDateTime currentDateTime = LocalDateTime.now();
        return currentDateTime.format(DateTimeFormat);
    }
	// ISO date time format with milleseconds and timezome
	public static String isoDateTime() {
		//ZoneDateTime is used to include information about offsets as 0.2:00
		ZonedDateTime zdt = ZonedDateTime.now(); 
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX");
		String formattedDateTime = zdt.format(formatter);
		return formattedDateTime;
		
	}
	
}
