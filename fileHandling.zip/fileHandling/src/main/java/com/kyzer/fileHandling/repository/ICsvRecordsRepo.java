package com.kyzer.fileHandling.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kyzer.fileHandling.domain.Records;

@Repository
public interface ICsvRecordsRepo  extends JpaRepository<Records,Long>{

	List<Records> findByNameAndSubject(String name, String subject);

}
