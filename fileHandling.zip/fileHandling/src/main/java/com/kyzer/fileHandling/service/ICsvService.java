package com.kyzer.fileHandling.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.kyzer.fileHandling.domain.Employee;
import com.opencsv.exceptions.CsvValidationException;

public interface ICsvService {

	

	List<Employee> saveData(MultipartFile file) throws CsvValidationException, IOException;

	void saveData1(MultipartFile file) throws CsvValidationException, IOException;

	List<Employee> saveData();

	String saveLocal(MultipartFile file) throws IllegalStateException, IOException;

	void writeDataToCsv(MultipartFile file, String data) throws IOException;

	


	List<Employee> findName(String name);

//
//	List<Emp> findByDate(LocalDate startDate, LocalDate endDate);
//
//	List<Emp> findDate(LocalDate date);
//
//	

	

	
}
