package com.kyzer.fileHandling.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.kyzer.fileHandling.service.PdfService;

@RestController
@RequestMapping("/PDF")
public class PdfController {

	@Autowired
	private PdfService pdfService;

	// read the data from the pdf file
	@PostMapping("/pdfRead")
	public String FileUpload(@RequestParam("file") MultipartFile file) throws IOException {

		return pdfService.pdfFileUpload(file);

	}

	// write the data into pdf file and create new pdf in localDisk
	@PostMapping("/witePdfToLocalDisk")
	public ResponseEntity<String> writePdf(@RequestParam String filePath, @RequestParam String content) {
		try {
			pdfService.createPdf(filePath, content);
			return ResponseEntity.ok("PDF created successfully at " + filePath);
		} catch (IOException e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create PDF");
		}

	}
}
