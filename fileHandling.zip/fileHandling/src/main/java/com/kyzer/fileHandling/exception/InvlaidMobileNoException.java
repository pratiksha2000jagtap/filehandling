package com.kyzer.fileHandling.exception;

public class InvlaidMobileNoException extends RuntimeException{

	public InvlaidMobileNoException(String message) 
	{
		super(message);
	}
}
