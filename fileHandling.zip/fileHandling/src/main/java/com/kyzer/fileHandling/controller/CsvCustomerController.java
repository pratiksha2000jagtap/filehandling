package com.kyzer.fileHandling.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.kyzer.fileHandling.domain.Customer;
import com.kyzer.fileHandling.exception.CustomerNameException;
import com.kyzer.fileHandling.exception.InvlaidMobileNoException;
import com.kyzer.fileHandling.service.ICsvCustomerService;
import com.kyzer.fileHandling.utilis.RegexUtils;
import com.opencsv.exceptions.CsvValidationException;

@RestController
@RequestMapping("/csv")
public class CsvCustomerController {

	@Autowired
	private ICsvCustomerService csvCustomerService;

	// upload CSV file save into database and give message
	@PostMapping("/uploadCsvToDatabase")
	public ResponseEntity<String> saveToDatabase(@RequestParam("file") MultipartFile file)	throws CsvValidationException, IOException, InvlaidMobileNoException {
		
	            csvCustomerService.saveData(file);
	            return ResponseEntity.status(HttpStatus.ACCEPTED).body("accepted: ");	     
	            } 
		
	
	
	
      

	// read all customer details of csv file
	@GetMapping("/getAllCsvDetails")
	public List<Customer> readCsv() {
		return csvCustomerService.readCsvDetails();

	}

	// save uploaded file to local disk
	@PostMapping("/saveCsvToLocalDisk")
	public String uploadLocalDisk(@RequestParam("file") MultipartFile file) throws IOException {
		String filePath = csvCustomerService.saveLocal(file);
		return "file saved successfully";

	}

	@PostMapping("/writeCsv")
	public ResponseEntity<String> writeCsvFile(@RequestParam("file") MultipartFile file,
			@RequestParam("data") String data) throws IOException {

		csvCustomerService.writeDataToCsv(file, data);
		return ResponseEntity.ok().body("Data has been written to CSV file successfully.");

	}

	// Retrieve date from database in dd-mm-yyyy format whose subsciptionDate is
	// >=2022
	@GetMapping("/subscriptionDatesFrom2022")
	public List<String> getSubscriptionDatesFrom2022Formatted() {
		return csvCustomerService.findSubscriptionDatesFrom2022Formatted();
	}

	@GetMapping("/findByDateBetween")
	// DateTimeFormat.ISO.DATE is used to convert string into LocalDate format
	public List<Customer> getCustomerByDate(@RequestParam @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate startDate,
			@RequestParam @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate endDate) {
		return csvCustomerService.findByDate(startDate, endDate);
	}


	//read unique records from csv file and print it in console
	@PostMapping("/readCsv")
    public ResponseEntity<String> processCsvFile(@RequestParam("file") MultipartFile file) throws CsvValidationException, IOException {
        
            csvCustomerService.processCsv(file);
            return ResponseEntity.status(HttpStatus.OK).body("file uploaded successfully");
	
	
    }
	// save unique records from csv into database
	@PostMapping("/upload")
    public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile file) throws CsvValidationException, NumberFormatException, IOException{
      
            csvCustomerService.saveCsv(file);
            return ResponseEntity.status(HttpStatus.OK).body("data saved  successfully");
     
    }
	
	@PostMapping("/updateRecords")
    public ResponseEntity<String> updateRecords(@RequestParam("file") MultipartFile file) throws CsvValidationException, NumberFormatException, IOException{
      
            csvCustomerService.updateDataOfCsv(file);
            return ResponseEntity.status(HttpStatus.OK).body("data updated  successfully");
     
    }
	
	
	
}
