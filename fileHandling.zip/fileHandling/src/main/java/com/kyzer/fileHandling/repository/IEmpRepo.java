package com.kyzer.fileHandling.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kyzer.fileHandling.domain.Employee;


@Repository
public interface IEmpRepo extends JpaRepository<Employee, Long> {

//	@Query("SELECT e FROM Emp e WHERE e.date BETWEEN :startDate AND :endDate")
//	List<Emp> findByDateRange(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
//
//	List<Emp> findByDate(LocalDate date);

}
