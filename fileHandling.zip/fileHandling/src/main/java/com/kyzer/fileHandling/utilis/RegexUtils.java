package com.kyzer.fileHandling.utilis;

import java.util.regex.Pattern;

import com.kyzer.fileHandling.exception.InvalidEmailException;
import com.kyzer.fileHandling.exception.InvlaidMobileNoException;

public class RegexUtils {

//	public static final String EMAIL_REGEX_PATTERN = "^[a-zA-Z0-9_+&*-]+@[a-zA-Z0-9_+&*-]$";
//	private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX_PATTERN);
//
//	public static final Pattern PHONE_NUMBER_PATTERN = Pattern.compile("\\d{10}");
//
//	public static boolean isValidEmail(String email) {
//		return email!=null && EMAIL_PATTERN.matcher(email).matches();
//	}

	
//	public static boolean isValidPhone1Number1(String phone1) {
//	return phone1.matches("\\d{10}");
//}
//
	
	
//	
//	public static boolean isValidPhone2Number1(String phone1) {
//		return phone1.matches("\\d{10}");
//	}
//	
	
	
	
	
	public static final String EMAIL_REGEX_PATTERN = "^[a-zA-Z0-9_+&*-]+@[a-zA-Z0-9_+&*-]+(\\.[a-zA-Z0-9_+&*-]+)+$";
    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX_PATTERN);

    public static boolean isValidEmail(String email) {
        if (email == null || !EMAIL_PATTERN.matcher(email).matches()) {
            throw new InvalidEmailException("Invalid Email: " + email);
        }
        return true;
    }


    public static final Pattern PHONE_NUMBER_PATTERN = Pattern.compile("\\d{10}");
	
	public static boolean isValidPhone1Number(String phone1) {
        if (phone1 == null || !PHONE_NUMBER_PATTERN.matcher(phone1).matches()) {
            throw new InvlaidMobileNoException("Invalid Phone 1 number: " + phone1);
        }
        return true;
    }
	public static boolean isValidPhone2Number(String phone2) {
        if (phone2 == null || !PHONE_NUMBER_PATTERN.matcher(phone2).matches()) {
            throw new InvlaidMobileNoException("Invalid Phone 2 number: " + phone2);
        }
        return true;
    }

	
}
