package com.kyzer.fileHandling.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="product")
public class product {
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name="id")
private Long id;
	@Column(name="name")
private String name;
}
