package com.kyzer.fileHandling.domain;

import javax.validation.constraints.Size;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="data")
public class Data {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "name")
    @Size(min = 5, max = 10, message = "Name must be between 5 and 10 characters")
    private String name;
    
    @Column(name = "value")
    private int value;
    
    @Column(name = "mob_no")
    private String mobNo;
    
    @Column(name = "country")
    private String country;
    
    @Column(name = "address")
    private String address;
    
    @Column(name = "is_valid")
    private int isValid; // changed 'is_valid' to 'isValid' to follow Java naming conventions
    
    @Column(name="error_msg")
    private String error_msg;
    
    
    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getMobNo() {
        return mobNo;
    }

    public void setMobNo(String mobNo) {
        this.mobNo = mobNo;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getError_msg() {
		return error_msg;
	}

	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}

	public int getIsValid() {
        return isValid;
    }

    public void setIsValid(int isValid) {
        this.isValid = isValid;
    }

	public Data(Long id, String name, int value, String mobNo, String country, String address, int isValid) {
		super();
		this.id = id;
		this.name = name;
		this.value = value;
		this.mobNo = mobNo;
		this.country = country;
		this.address = address;
		this.isValid = isValid;
	}

	public Data() {
		super();
		// TODO Auto-generated constructor stub
	}

	


}
