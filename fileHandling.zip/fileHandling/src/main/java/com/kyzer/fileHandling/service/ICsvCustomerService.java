package com.kyzer.fileHandling.service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.kyzer.fileHandling.domain.Customer;
import com.kyzer.fileHandling.exception.InvlaidMobileNoException;
import com.opencsv.exceptions.CsvValidationException;

public interface ICsvCustomerService {

	void saveData(MultipartFile file) throws CsvValidationException, IOException;

	List<Customer> readCsvDetails();

	String saveLocal(MultipartFile file) throws IOException;

	void writeDataToCsv(MultipartFile file, String data) throws IOException;

	List<String> findSubscriptionDatesFrom2022Formatted();

	List<Customer> findByDate(LocalDate startDate, LocalDate endDate);

	List<String[]> processCsv(MultipartFile file) throws IOException, CsvValidationException;

	void saveCsv(MultipartFile file) throws IOException, CsvValidationException, NumberFormatException;

	void updateDataOfCsv(MultipartFile file) throws IOException, CsvValidationException, NumberFormatException;


}
