package com.kyzer.fileHandling.serviceImpl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.kyzer.fileHandling.domain.Employee;
import com.kyzer.fileHandling.repository.ICsvRepo;
import com.kyzer.fileHandling.repository.IEmpRepo;
import com.kyzer.fileHandling.service.ICsvService;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

@Service
public class CsvServiceImpl implements ICsvService {
	@Autowired
	private ICsvRepo employeeRepo;
	
	@Autowired IEmpRepo empRepo;

	private final String UPLOAD_DIR = "D://CSV/";

	@Override
	public List<Employee> saveData(MultipartFile file) throws CsvValidationException, IOException {
		List<Employee> employees = new ArrayList<>();
		CSVReader reader = new CSVReader(new InputStreamReader(file.getInputStream()));
		String[] lines;
		// skip header line
		reader.readNext();
		while ((lines = reader.readNext()) != null) {
			Employee employee = new Employee();
			employee.setName(lines[0]);
			employee.setLname(lines[1]);
			employee.setSalary(lines[2]);
			employee.setDate(lines[3]);
			employee.setTime(lines[4]);
			employees.add(employee);

		}
		employeeRepo.saveAll(employees);
		return employees;
	}

	@Override
	public void saveData1(MultipartFile file) throws CsvValidationException, IOException {

		List<Employee> employees = new ArrayList<>();
		CSVReader reader = new CSVReader(new InputStreamReader(file.getInputStream()));
		String[] lines;
		// skip header line
		reader.readNext();
		while ((lines = reader.readNext()) != null) {
			Employee employee = new Employee();
			employee.setName(lines[0]);
			employee.setLname(lines[1]);
			employee.setSalary(lines[2]);
			employee.setDate(lines[3]);
			employee.setTime(lines[4]);
			employees.add(employee);

		}
		employeeRepo.saveAll(employees);
	}

	@Override
	public List<Employee> saveData() {
		return employeeRepo.findAll();

	}

	@Override
	public String saveLocal(MultipartFile file) throws  IOException {
		String fileName = file.getOriginalFilename();
		// UPLOAD_DIR is used to represent directory where you want to upload file
		String filePath = UPLOAD_DIR + fileName;
		// paths.get() method represent location where you want to save file on local
		Path path = Paths.get(filePath);
		// If directories does not exist it create the directory
		Files.createDirectories(path.getParent());
		// write the content of uploaded file in particular path in the form of byte
		// array
		Files.write(path, file.getBytes());

		return filePath;
	}

	public void writeDataToCsv(MultipartFile file, String data) throws IOException {
		// Get the original filename
		String fileName = file.getOriginalFilename();
		// Construct the file path where the CSV file will be saved
		String filePath = "D://CSV/" + fileName;
		System.out.println(new Date());

		try (BufferedWriter writer = new BufferedWriter(new FileWriter(new File(filePath)))) {
			// Write data to the CSV file
			writer.write(data);
		}
	}

	@Override
	public List<Employee> findName(String name) {
		return employeeRepo.findByname(name);

	}

//	@Override
//	public List<Employee> findByDate(String startDate, String endDate) {
//		
//		return employeeRepo.findByDateRange(startDate,endDate);
//	}

//	@Override
//	public List<Emp> findByDate(LocalDate startDate, LocalDate endDate) {
//	    return empRepo.findByDateRange(startDate, endDate);
//	}
//
//	@Override
//	public List<Emp> findDate(LocalDate date) {
//		return empRepo.findByDate(date);
//	}
}