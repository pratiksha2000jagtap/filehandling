package com.kyzer.fileHandling.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.kyzer.fileHandling.domain.Data;
import com.kyzer.fileHandling.domain.ErrorLog;

public interface IDataService {

	void saveData(Data validEntry);

	void saveErrorLog(ErrorLog errorLog);

	

}
