package com.kyzer.fileHandling.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.kyzer.fileHandling.domain.Employee;
import com.kyzer.fileHandling.service.ICsvService;
import com.kyzer.fileHandling.utilis.DateTimeUtils;
import com.opencsv.exceptions.CsvValidationException;

@RestController
@RequestMapping("/api")
public class CsvController {

	@Autowired
	private ICsvService employeeService;

	// upload CSV file save into database and give message
	@PostMapping("/uploadCsv")
	public ResponseEntity<String> saveToDatabase(@RequestParam("file") MultipartFile file)
			throws IOException, CsvValidationException {

		employeeService.saveData1(file);
		return ResponseEntity.status(HttpStatus.OK).body("file uploaded successfully");

	}

	// upload CSV file save to DataBase and return employee details
	@PostMapping("/uploadCsv1")
	public List<Employee> uploadFile(@RequestParam("file") MultipartFile file)
			throws CsvValidationException, IOException {
		return employeeService.saveData(file);

	}

	// read all employee details save in database
	@GetMapping("/getAllEmployeeCsv")
	public List<Employee> getEmployee() {
		return employeeService.saveData();

	}

	// save uploaded file to local disk
	@PostMapping("/saveCsvToLocalDisk")
	public String uploadLocalDisk(@RequestParam("file") MultipartFile file) throws IOException {
		String filePath = employeeService.saveLocal(file);
		return "file saved successfully";

	}

	// write data in CSV file through postman and create new file in directory
	@PostMapping("/writeCsv")
	public ResponseEntity<String> writeCsvFile(@RequestParam("file") MultipartFile file,
			@RequestParam("data") String data) {
		try {
			employeeService.writeDataToCsv(file, data);
			return ResponseEntity.ok().body("Data has been written to CSV file successfully.");
		} catch (IOException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Failed to write data to CSV file: " + e.getMessage());
		}
	}

	// get the current date according to "yyyy/dd/mm format
	@GetMapping("/Date")
	public String getCurrentDate() {
		// call the method of DateTime class to get formated date
		System.out.println(new Date());
		String formattedDate = DateTimeUtils.getCurrentDateFormatted();
		return "Current Date: " + formattedDate;
	}

	// get the current date according to "dd/MM/yyyy"
	@GetMapping("/Date1")
	public String getCurrentDate1() {
		// call the method of DateTime class to get formated date
		String formattedDate = DateTimeUtils.getCurrentDateFormatted1();
		return "Current Date: " + formattedDate;
	}

	// get the current time
	@GetMapping("/Time")
	public String getCurrentDateTime() {
		String newDateTime = DateTimeUtils.CurrentDateTimeFormaterr();
		return "Current Date Time:" + newDateTime;
	}

	// Get current date and time
	@GetMapping("/DateTime")
	public String formatedDateTime() {
		String updatedDateTime = DateTimeUtils.getCurrentDateTimeFormatted();
		return "Current Date Time:" + updatedDateTime;

	}

	// Get the date and time according ISO
	@GetMapping("/ISODateTime")
	public String getIsoDateTime() {
		String formattedDate = DateTimeUtils.isoDateTime();
		return "ISO Date Time:" + formattedDate;

	}

	// Get Employee By Name
	@GetMapping("/findByName")
	public List<Employee> getByEmployeeName(@RequestParam String name) {
		return employeeService.findName(name);
	}

//	// get the employee between particular range
//	@GetMapping("/findByDateBetween")
//	// DateTimeFormat.ISO.DATE is used to convert string into LocalDate format
//	public List<Emp> getEmployeeByDate(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
//			@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
//		return employeeService.findByDate(startDate, endDate);
//	}
//
//	// get the employee details of particular date
//	@GetMapping("/getByDate")
//	public List<Emp> getEmployeeByDate(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
//		return employeeService.findDate(date);
//
//	}

}
