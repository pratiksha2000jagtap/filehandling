package com.kyzer.fileHandling.serviceImpl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.kyzer.fileHandling.domain.Customer;
import com.kyzer.fileHandling.domain.Records;
import com.kyzer.fileHandling.exception.CustomerNameException;
import com.kyzer.fileHandling.exception.InvalidEmailException;
import com.kyzer.fileHandling.exception.InvlaidMobileNoException;
import com.kyzer.fileHandling.repository.ICsvCustomerRepo;
import com.kyzer.fileHandling.repository.ICsvRecordsRepo;
import com.kyzer.fileHandling.service.ICsvCustomerService;
import com.kyzer.fileHandling.utilis.RegexUtils;
import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;

@Service
public class CsvCustomerServiceImpl implements ICsvCustomerService {

	private static final Logger logger = LoggerFactory.getLogger(CsvCustomerServiceImpl.class);
	@Autowired
	ICsvCustomerRepo csvCustomerRepo;

	@Autowired
	ICsvRecordsRepo csvRecordsRepo;

	private final String UPLOAD_DIR = "D://CSV/";

//	@Transactional(rollbackFor = CustomerNameException.class)
	public void saveData(MultipartFile file) throws CsvValidationException, IOException {

		List<Customer> customers = new ArrayList<>();
		CSVReader reader = new CSVReader(new InputStreamReader(file.getInputStream()));
		String[] lines;
		// skip header line
		reader.readNext();

		while ((lines = reader.readNext()) != null) {
			try {
				Customer customer = new Customer();
				customer.setIndex(Long.parseLong(lines[0]));
				customer.setCustomerid(lines[1]);
				// Validate and set first name
				if (lines[2] == (null) || lines[2].isEmpty()) {

					throw new CustomerNameException(
							"Customer First name cannot be null or empty for customer ID:" + customer.getId());
				}
				customer.setFirstName(lines[2]);
				// Validate and set first name
				if (lines[3] == (null) || lines[3].isEmpty()) {

					throw new CustomerNameException(
							"Customer Last name cannot be null or empty for customer ID:" + customer.getId());
				}
				customer.setLastName(lines[3]);

				customer.setCompany(lines[4]);
				customer.setCity(lines[5]);
				customer.setCountry(lines[6]);
				customer.setPhone1(lines[7]);
//
//				if (RegexUtils.isValidPhone1Number(lines[7])) {
//					customer.setPhone1(lines[7]);
//
//				} else {
//					logger.error("invaid phone no");
//
//				}

				if (RegexUtils.isValidPhone1Number(lines[7])) {
					customer.setPhone1(lines[7]);
				} else {
					logger.error("Invalid phone number: " + lines[7]);
					throw new InvlaidMobileNoException("Invalid phone number for customer ID: " + customer.getId());
				}

				if (RegexUtils.isValidPhone2Number(lines[8])) {
					customer.setPhone2(lines[8]);
				} else {
					logger.error("Invalid phone number: " + lines[8]);
					throw new InvlaidMobileNoException("Invalid phone number for customer ID: " + customer.getId());
				}
				
				if (RegexUtils.isValidEmail(lines[9])) {
					customer.setEmail(lines[9]);
				} else {
					logger.error("Invalid email format: " + lines[9]);
					throw new InvalidEmailException("Invalid email format for customer ID: " + customer.getId());
				}
//				if (RegexUtils.isValidEmail(lines[9])) {
//					customer.setEmail(lines[9]);
//				} else {
//					logger.error("invalid email ");
//
//				}
				// trim() for whitespaces
				String dateString = lines[10].trim();
				if (!dateString.isEmpty()) {
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
					LocalDate subscriptionDate = LocalDate.parse(dateString, formatter);
					customer.setSubscriptionDate(subscriptionDate);
				} else {
					// Handle empty date string (if required)
					customer.setSubscriptionDate(null);
				}
				customer.setWebsite(lines[11]);
				csvCustomerRepo.save(customer);
				// customers.add(customer);
			} catch (CustomerNameException ex) {
				// Log the specific line or ID where the exception occurred
				logger.error("Error processing customer data for line: " + lines[0] + ". Message: " + ex.getMessage());

				throw ex; // This re-throws the exception to be caught by the controller advice

			} catch (InvlaidMobileNoException ivm) {
				// Log the specific line or ID where the exception occurred
				logger.error("Error processing customer data for line: " + lines[0] + ". Message: " + ivm.getMessage());

				throw ivm; // This re-throws the exception to be caught by the controller advice

			} catch (InvalidEmailException ex) {
				logger.error("Error processing customer email for line: " + lines[0] + ". Message: " + ex.getMessage());
				throw ex; // Propagate the exception to be handled globally
			}
			// csvCustomerRepo.saveAll(customers);
		}
	}

	@Override
	public List<Customer> readCsvDetails() {

		return csvCustomerRepo.findAll();
	}

	@Override
	public String saveLocal(MultipartFile file) throws IOException {

		String fileName = file.getOriginalFilename();
		// UPLOAD_DIR is used to represent directory where you want to upload file
		String filePath = UPLOAD_DIR + fileName;
		// paths.get() method represent location where you want to save file on local
		Path path = Paths.get(filePath);
		// If directories does not exist it create the directory
		Files.createDirectories(path.getParent());
		// write the content of uploaded file in particular path in the form of byte
		// array
		Files.write(path, file.getBytes());

		return filePath;
	}

	@Override
	public void writeDataToCsv(MultipartFile file, String data) throws IOException {
		String fileName = file.getOriginalFilename();
		// Construct the file path where the CSV file will be saved
		String filePath = "D://CSV/" + fileName;
		System.out.println(new Date());

		try (BufferedWriter writer = new BufferedWriter(new FileWriter(new File(filePath)))) {
			// Write data to the CSV file

			writer.write(data);
		}

	}

	@Override
	public List<String> findSubscriptionDatesFrom2022Formatted() {

		return csvCustomerRepo.findSubscriptionDatesFrom2022Formatted();
	}

	@Override
	public List<Customer> findByDate(LocalDate startDate, LocalDate endDate) {

		return csvCustomerRepo.findByRange(startDate, endDate);
	}

	public List<String[]> processCsv(MultipartFile file) throws IOException, CsvValidationException {
		Set<String> uniqueNames = new HashSet<>();

		// BufferReader is used to read csv file
		BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()));

		// create CSVParser with specific deliminter
		// CSVParser is to take a single string and parse it into its elements based on
		// the delimiter
		CSVParser csvParser = new CSVParserBuilder().withSeparator('|').build();

		// create CSVReader with specific csvParser
		CSVReader csvReader = new CSVReaderBuilder(reader).withCSVParser(csvParser).build();
		String[] line;

		while ((line = csvReader.readNext()) != null) {
			if (line.length >= 5) {

				String name = line[1];
				String subject = line[3];

				// Check if name already exists in the set
				if (!uniqueNames.contains(name) && !uniqueNames.contains(subject)) {
					uniqueNames.add(name);
					uniqueNames.add(subject);

					// Print the record to the console
					System.out.println(String.join("|", line));
				}
			}
		}
		return null;
	}

	public void saveCsv(MultipartFile file) throws IOException, CsvValidationException, NumberFormatException {
		Set<String> uniqueNames = new HashSet<>();

		BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()));
		CSVParser csvParser = new CSVParserBuilder().withSeparator('|').build();
		CSVReader csvReader = new CSVReaderBuilder(reader).withCSVParser(csvParser).build();

		String[] line;
		List<Records> recordsToSave = new ArrayList<>();

		// Skip the header line assuming it contains column names
		csvReader.skip(1);

		while ((line = csvReader.readNext()) != null) {
			if (line.length >= 5) {
				String name = line[1];
				String subject = line[3];

				// Check if name and subject already exists in the set
				if (!uniqueNames.contains(name) && !uniqueNames.contains(subject)) {
					uniqueNames.add(name);
					uniqueNames.add(subject);

					// Create Record object
					Records record = new Records();
					record.setName(name);
					record.setValue(Integer.parseInt(line[2]));
					record.setSubject(subject);
					record.setMarks(Integer.parseInt(line[4]));

					recordsToSave.add(record);

					// Print the record to the console (optional)
					System.out.println(String.join("|", line));
				}
			}
		}

		// Save records to the database
		csvRecordsRepo.saveAll(recordsToSave);
	}

	public void updateDataOfCsv(MultipartFile file) throws IOException, CsvValidationException {
		Set<String> uniqueNames = new HashSet<>();

		BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()));
		// CSVReader and CsvPaerse is used to parse the data from csv file
		CSVParser csvParser = new CSVParserBuilder().withSeparator('|').build();
		CSVReader csvReader = new CSVReaderBuilder(reader).withCSVParser(csvParser).build();

		String[] line;
		// recordsToSave is used to store Records Object that saved or updated to
		// database
		List<Records> recordsToSave = new ArrayList<>();

		// Skip the header line assuming it contains column names
		csvReader.skip(1);

		while ((line = csvReader.readNext()) != null) {
			if (line.length >= 5) {
				String name = line[1];
				String subject = line[3];
				if (!uniqueNames.contains(name) && !uniqueNames.contains(subject)) {
					uniqueNames.add(name);
					uniqueNames.add(subject);

					// Check if record with same name and subject exists in the database
					List<Records> existingRecords = csvRecordsRepo.findByNameAndSubject(name, subject);

					// if existing record is not empty means same and same subject data found in
					// database
					if (!existingRecords.isEmpty()) {
						// Update existing records
						for (Records existingRecord : existingRecords) {
							existingRecord.setValue(Integer.parseInt(line[2]));
							existingRecord.setMarks(Integer.parseInt(line[4]));
							recordsToSave.add(existingRecord);
						}
					} else {
						// Create new record
						Records record = new Records();
						record.setName(name);
						record.setValue(Integer.parseInt(line[2]));
						record.setSubject(subject);
						record.setMarks(Integer.parseInt(line[4]));
						recordsToSave.add(record);
					}

					// Print the record to the console (optional)
					System.out.println(String.join("|", line));
				}
			}
		}

		// Save records new or updated to the database
		csvRecordsRepo.saveAll(recordsToSave);
	}

}
