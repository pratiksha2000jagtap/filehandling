package com.kyzer.fileHandling.serviceImpl;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.kyzer.fileHandling.domain.Data;
import com.kyzer.fileHandling.domain.ErrorLog;
import com.kyzer.fileHandling.repository.IDataRepo;
import com.kyzer.fileHandling.repository.IErrorLogRepo;
import com.kyzer.fileHandling.service.IDataService;

@Service
public class DataService implements IDataService{

	
	@Autowired
	private IDataRepo dataRepo;
	
	@Autowired
	private IErrorLogRepo errorLogRepo;

	@Override
	public void saveData(Data validEntry) {
		dataRepo.save(validEntry);
		
	}

	@Override
	public void saveErrorLog(ErrorLog errorLog) {
		errorLogRepo.save(errorLog);
		
	}

	
	
	 

	
	
	}

