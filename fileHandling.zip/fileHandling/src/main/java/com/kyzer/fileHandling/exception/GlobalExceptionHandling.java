package com.kyzer.fileHandling.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandling {
	
	@ExceptionHandler(CustomerNameException.class)
    public ResponseEntity<?> handleFileHandlingException(CustomerNameException ex) {
		
		Map<String, Object> returnMap = new HashMap<>();
		returnMap.put("Message", ex.getMessage());
		returnMap.put("Status", "Failed");
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(returnMap);
    }
	
	@ExceptionHandler(InvlaidMobileNoException.class)
	public ResponseEntity<?> MobileNoException(InvlaidMobileNoException ivm){
		Map<String ,Object> m = new HashMap<>();
		m.put("message", ivm.getMessage());
		m.put("Status", "failed");
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(m);
	}
	
	
	public ResponseEntity<?> EmailException(InvalidEmailException ex){
		Map<String,Object> map=new HashMap();
		map.put("message",ex.getMessage());
		map.put("Status","failed");
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(map);
		
	}
}
