package com.kyzer.fileHandling.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kyzer.fileHandling.domain.ErrorLog;

@Repository
public interface IErrorLogRepo extends JpaRepository<ErrorLog,Long>{

}
