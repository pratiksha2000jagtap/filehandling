package com.kyzer.fileHandling.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.kyzer.fileHandling.domain.Data;
import com.kyzer.fileHandling.repository.IDataRepo;
import com.kyzer.fileHandling.service.IDataService;

@RestController
@RequestMapping("/Data")
public class DataController {

	@Autowired
	private IDataService dataService;
	@Autowired
	IDataRepo dataRepo;

	@PostMapping("/upload")
	public String uploadCsvFile(@RequestParam("file") MultipartFile file) throws NumberFormatException, IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()));
		String line;

		int lineCount = 0;

		while ((line = br.readLine()) != null) {
			lineCount++;

			// Skip header line if necessary
			if (lineCount == 1) {
				continue;
			}

			String[] data = line.split("\\|");

			if (data.length != 6) {
				return "Error: Invalid CSV format at line " + lineCount;

			}

			// create new CsvData object and assign data object to its filed
			Data csvData = new Data();
			csvData.setName(data[1]);
			csvData.setValue(Integer.parseInt(data[2]));
			csvData.setMobNo(data[3]);
			csvData.setCountry(data[4]);
			csvData.setAddress(data[5]);
			csvData.setIsValid(1);
			StringBuffer sb = new StringBuffer();
			// Validate 'NAME' field
			if (csvData.getName().length() < 5 || csvData.getName().length() > 10) {
				csvData.setIsValid(0);
				sb.append("Error: Invalid 'NAME' length at line " + lineCount + ". Must be between 5 and 10 characters.");
				// "Error: Invalid 'NAME' length at line " + lineCount + ". Must be between 5
				// and 10 characters.";
			}

			if (csvData.getAddress().length() < 5 || csvData.getAddress().length() > 255) {
				csvData.setIsValid(0);
				sb.append("Error: Invalid 'Address' length at line " + lineCount + ". Must be between 5 and 255 characters.");

			}
			// Validate mobile number
			if (!isValidMobileNumber(csvData.getMobNo())) {
				csvData.setIsValid(0);
				sb.append("Error: Invalid mobile number at line " + lineCount + ". Must be 10 digits.");
			}
			if (csvData.getCountry().equalsIgnoreCase("India")) {
				// If country is India, validate the mobile number starts with 9, 7, or 8
				if (!isValidIndianMobileNumber(csvData.getMobNo())) {
					csvData.setIsValid(0);
					sb.append("Error: Invalid mobile number for India at line " + lineCount
							+ ". Must start with 9, 7, or 8.");
				}
			} else {
			}

			try {
				csvData.setError_msg(sb.toString());

				dataRepo.save(csvData); // Assuming saveData method handles saving to database
			} catch (Exception e) {
				return "Error occurred while saving data at line " + lineCount + ": " + e.getMessage();
			}
		}

		return "CSV file uploaded and processed successfully.";

	}

	private boolean isValidMobileNumber(String mobNo) {
		return mobNo.matches("\\d{10}");
	}

	private boolean isValidIndianMobileNumber(String mobNo) {
		return mobNo.matches("[7-9]\\d{9}");
	}
}
