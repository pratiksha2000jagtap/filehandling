package com.kyzer.fileHandling.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.kyzer.fileHandling.domain.Customer;
import com.kyzer.fileHandling.domain.Records;

@Repository
public interface ICsvCustomerRepo extends JpaRepository<Customer, Long> {
	
	// Date_Format convert the date in dd-mm-yyyy format %d is used for (1-31) ,%m is (1-12),%y is year 2022
	@Query("SELECT DATE_FORMAT(c.subscriptionDate, '%d/%m/%Y') FROM Customer c WHERE YEAR(c.subscriptionDate) >= 2022")
	List<String> findSubscriptionDatesFrom2022Formatted();
	
	// c is alias to refer customer table
	@Query(value = "SELECT c FROM Customer c WHERE c.subscriptionDate BETWEEN :startDate AND :endDate")
	List<Customer> findByRange(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

	

}
