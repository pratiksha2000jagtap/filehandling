package com.kyzer.fileHandling.exception;

public class CustomerNameException extends RuntimeException {

	public CustomerNameException(String message) {
		super(message);
	}

}
