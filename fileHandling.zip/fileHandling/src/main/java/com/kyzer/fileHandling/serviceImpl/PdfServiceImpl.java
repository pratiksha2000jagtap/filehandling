package com.kyzer.fileHandling.serviceImpl;

import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.kyzer.fileHandling.service.PdfService;

@Service
public class PdfServiceImpl implements PdfService {

	public String pdfFileUpload(MultipartFile file) throws IOException {
		//PDDocument is the in memory representation of pdf
		PDDocument document = PDDocument.load(file.getInputStream());
		
		// PDFTextStripper class take all the text from the pdf ignoring font and all
		PDFTextStripper pdfStripper = new PDFTextStripper();
		
		// this will return the text of document
		String text = pdfStripper.getText(document);

		return text;
	}

	@Override
	public void createPdf(String filePath, String content) throws IOException {
		PDDocument document = new PDDocument();
		// A page in PDF format
		PDPage page=new PDPage();
		// this will add the page in the document
		document.addPage(page);
		// Gives permission to write to the page
		PDPageContentStream contentStream=new PDPageContentStream(document,page);
	
		contentStream.setFont(PDType1Font.TIMES_ROMAN, 24);
        contentStream.beginText();
        contentStream.showText(content); // Write your content here
        contentStream.endText();
        contentStream.close();
        document.save(filePath); // Save the document to a file
        document.close();
}
	}


