package com.kyzer.fileHandling.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

public interface PdfService {

 String pdfFileUpload(MultipartFile file) throws IOException;

void createPdf(String filePath, String content) throws IOException;
		
}
